// If else statements
// a method for running a block of code , while the condition is true







// Syntax

// If syntax (Check if condition is true , if it is then the block of code will run and will not check other statements and condition is not true then will check another statement)
let condition = false
if (condition) {
    console.log("run");
}
// Else If syntax  (if multiple statements u need to check)
else if (condition) {
    console.log("run nigger");
    console.log("u are not fast enough");
}
// Else syntax (if none of the above condition is true then this will only run)
else{
    console.log();
}
// An "if else" statement will continue examine the correct condition until it encounter an "else" statement or an "if" statement 
// If u used more than one "if" statement and all "if" will be different statements





// Blockless if statement
//  (just like if else statment but without block which mean u can't declared a variable and can only right multiples lines of statment using ",")
if(false) console.log("perspective") , console.log("hello"),
console.log("world")
// use only when to flex on nerds


// Ternary operator (when u want to run only one of two statements)
// use "?" after condition followed by true values then ":" followed by default/else value 
condition ? "trueValue" : "falseValue";


// Short-circuit if statement (used for running only one statements)
condition && console.log("vivek")

