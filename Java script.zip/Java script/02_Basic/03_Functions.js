// Functions
// Used to store a block of code that u can execute as u want





// Creating a fnc litreals
// 1. regular fnc (u have to use 'function' keyword followed by name( or if u don't use name u can store it inside variable))
function regular_fnc(){}
// 2.Anonymous function
let regular_fnc1 = function(){}
// 3. Arrow fnc (it works better than regular fnc for short code or rediability)
// syntax
let arrow_fnc = () => {}
// 4.Immediately invoked function (IIFE) , means executed exactly after time of creation
// syntax "(function)()"
(function IIFE(){})()


// Creating a fnc constructor 
// if u create an fnc constructor it will give u an empty object unless u put your own property to that fnc
// Although "this" context(value) is global object inside fnc but we are creating instance(object) of that fnc so it will make an object with "This.name/class" as it's keys 
let fnc_constructor = new function(classes){
    this.name = "value"
    this.class = classes
}


// calling/running a fnc
// To run a fnc u just need "()" after that fnc name (or the variable u stored the fnc in) to run/call it without "()" it will just give the reference of that fnc , will not call/run it
regular_fnc()
//after calling/run a fnc all the lines of code inside fnc will be excuted and after all ,it returns a value (if u have one) ,return is the end point of fnc excution after return value fnc will not execute the code further  
// But in "IIFE" u don't need to call it bc it already called/run/executed at the time of creation




// Return value ( Except "IIFE" all fnc have return value(optional)) , it's only used inside fnc , and it's kinda fullstop for code execution
// if a function doesn't explicitly have a return statement, it implicitly returns undefined
// Without return values fncs are called void fnc in other languages , but in js void is used for differently
function doSomething() {
  }
  // Using void to execute a function and ignore its return value i.e undefined
  void doSomething();


//  Syntax (For executing all the afterward code we need to comment "return" keyword ,feel free to uncomment it)
/*
return "return values"

// for more than one line of return value u can use "()" to close it

return(
    "return values",
    88
)
*/

// Parameters/arguments 
// U can give some specific values to fnc in creation or executing phase, so it can only be use by it directly without exploiting values to variables, In a Nutshell for "clean code"
// declaring variables/values in creating phase are called "parameters" (u can also declare and assign at the same time)
function fnc(first,second,third = "world"){
    console.log(first,second,third);
}
// assigning variables/values in execution phase are called "arguments"
// fnc("hello",69)

// In a nutshell u can say parameters are variables and values are agruments , all the values will be assigned to the variables correspondingly (already assigned variable will be overridden by arguments in executing phase)
// For assigning more than one value to same parameter(variable) in a fnc , u can operator "..." before the parameter and it will gasp(eat) all overflowed values
// U can pass any type of values as arguments i.e array,string,object
function object_parameters(value = {1:value,2:variable}){
    console.log(value);
}
// object_parameters({1:"perspective",2:"name"})
// "value" value is overrridden at the time of execution