// Data Catygory

// Heap Memory and stack memory 
// All the Primitive Data type those comes under stack memory i.e Which data type that get stacked by stacked(Imaginary concept) without chaning anything inside original data
// All the Non Primitive or we can say the Data we use by their refereence are comes under heap memory

// Primitive Data type 
// These are the basic data types in JavaScript that store a copy of the actual data. They include:
// 1. Strings , 2.Numbers , 3.Boolean , 4.Undefined , 5.null , 6.Symbol , 7.BigInt


// non-Primitive (Reference) Data type
// Non-primitive data types do not store the data itself, but rather the memory address of where the data is stored. This means that they are not directly holding the value of the variable, but a reference to it. They include:

// 1. Array , 2. Object , 3.Function
// All non-primitive types are also considered as object type in JavaScript.