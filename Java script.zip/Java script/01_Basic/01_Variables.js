//  Variables  and Constant 

//Constant
const x = 12;  //declaring constant , and values can't be change now ,more or less u can't do anything with this code except using the value of x only


//Variables can be declare by two methods
let y = 12 ;  //decalring variable using let , the values can be changed after but can't declare same variable again
y = 11;  //Now y value changed to 11


var z = 12; //decalring variable using var , the values can be changed after and also u can declare the same variable again
var z = 11; //Now z variable is again declared
z = 10; //Now z value chnaged to 10


//Declaring variable without key also possible in js
a = 1

// Note : In javascript semicolan i.e: ";" used to break the code , even if u don't use it , it doesn't matter unless u write another code in same line

console.log() //To print values
console.table([a,x,y,z])  //Used to print values in a table form

