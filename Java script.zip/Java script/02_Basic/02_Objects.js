// Objects
// They can be created using the Object() constructor or the object literal syntax.
// Object literal
let object = {
    name: "perspective",
    class: 12
}

// Object Constructor (u can make constructor using "Object()" with "new" keyword and without it) 
let simple_object = Object()

let symbol = Symbol("key")  
let new_object = new Object({
    name: "perspective",
    "value of": 12,
    [symbol] : {
        first : "#*#",
        second : 911
    }
})

// All keys are stored in string form but u don't need to use ""/'' unless it's a special character or there is spaces in letters as key
// To store symbol as key u need to use "[]" brackets and for accesing symbol u also need "[]" brackets

// How to access object values (Object values are stored in "key:value" form so u can access them by using their key)
new_object.name  // acessing value using "." notation
new_object["value of"] // acessing value using [] brackets 
new_object[symbol] // acessing using [] brackets , it is usefull when u want to acess symbol or key that is not suitable to acess from "." notation i.e. key that contain spaces/special character  , Note : u need "" to access keys that are strings  only (all keys are stored as strings in objects except symbol)
// object[symbol]["second"]

// "this" keyword

// it have different values in different context
// 1. using "this" inside inside object represent the object itself even though it's used inside fnc
let object1 = {
    name : "perspective2",
   class : 12,
    fnc : function object(){
    console.log(this.name); 
   }
}

/*  object1["fnc"]()  
 object1.fnc()    
 to call an fnc inside object u can use () after accesing the value (because to call a fnc we use () after getting it's reference)
 import "./03_Functions.js" // plzz check this file before starting fnc
 */

// 2. using "this" inside regular fnc
// (i) without using strick mode ('use strict')
//  represented as the global object(global object inside browser : "windnow" , global object inside node.js/dino/bun env is "global")
// global objects is an object that contains all the properties of the env i.e browser or installed env 
function fnc(){
    console.log(this); // global object 
}

// (ii) using strick mode       i.e. 'use strict'
//  represented as undefined. 
// 'use strict'; Note : this is used at top level of code
function fnc1(){
    console.log(this); // undefiend only if there is strict mode
}

// 3. using "this" inside arrow fnc
// In an arrow function, "this" is not affected by strict mode
// Arrow functions do not have their own "this" context(value). They inherit the 'this' value from their "enclosing lexical scope"(unltimatly all properties will be same as global scope unless u define some custom propety inside an scope and use "this" inside the scope) at the time of creation
const arrowFunction = () => {
  console.log(this); // empty(export) object because of how nodejs treats "this" values inside arrow fnc and "top-level module scope"(outside of any function) 
};
// 4. using "this" as a value in global context represent global object but in node js env it will give u empty(exports) object
let value_of_this = this



// Object Methods

// freeze (used to stop an object from adding anyother value inside it in future)
Object.freeze(new_object) // put your object inside ()
new_object["name"] = "your name" // will not effect new_object or will give error in strict mode

// assign (used to concat objects inside an another object)
let final_object = Object.assign({},new_object,object,object1) // it returns an modified object in which all other argument objects except first are combined inside first(target) object , similar keys values will be overridden by upcoming object in argument
// spread operator (U can also use spread operator if u want to disintegrate objects into a new object Note: same key values will be overridden)
let final_object1 = {...object,...object1}

// keys,values,entries/hasOwnProperty/toString
let keys = Object.keys(final_object1)      // returns an array containing all keys from the object
let values = Object.values(final_object1)  // returns an array containing all values from the object
let entries = Object.entries(new_object)  // returns an array containing all entries(key:value) from the object
final_object1.hasOwnProperty(`name`)      //check weather the key is present in the object or not
final_object.toString()                   //used to check type of object i.e "[Object Object]" (first is it's nature(object) and second is it's type(object) )






// Object Destructuring 

// it's syntax is same as creating object litreals i.e. "{}" but When you use the "{}" syntax on the left side of an assignment, it becomes a destructuring pattern. It allows you to extract values from an object and assign them to variables(variable will be keys by deafault and if u want another variable name use ":" after accesing the variables).
// destructuring nested object is same but use ":{}" after accessing nested object (Note: there is no single syntax that can destructure and assign it's value to new variable u have to do that recursively(one by one))

let obj = { prop1: 'value1', prop2: 'value2', prop3: 'value3' ,prop4: { prop4:"value4" ,prop5:"value5"} };

let { prop1, prop2, prop3:variable , prop4:{prop4, prop5}, prop4:variable1 , prop6 = 'defaultValue'} = obj;

prop1     // 'value1'
prop2     // 'value2'
variable  // 'value3' 
variable1 // '{prop4: 'value4', prop5: 'value5'}'
// prop3  // don't exist 
prop4     // 'value4'
prop5     // 'value5'
prop6     // 'defaultValue'

console.log(obj.vivek);

// Future study : if u don't store an object it's treated as JSON i.e "{key: "value"}" , it's is treated as json unless n until u hold it inside a variable